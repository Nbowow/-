SELECT * FROM yorijori.materials;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=2"
where material_id = 1;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=185"
where material_id = 2;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=174"
where material_id = 3;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=174"
where material_id = 4;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=77"
where material_id = 5;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=237"
where material_id = 6;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=237"
where material_id = 7;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=82"
where material_id = 8;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=114"
where material_id = 9;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=57"
where material_id = 10;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=187"
where material_id = 11;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=190"
where material_id = 12;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=189"
where material_id = 13;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=189"
where material_id = 14;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=189"
where material_id = 15;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=182"
where material_id = 16;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=110"
where material_id = 17;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=160"
where material_id = 18;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=158"
where material_id = 19;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=158"
where material_id = 20;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=158"
where material_id = 21;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=158"
where material_id = 22;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=223"
where material_id = 23;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=223"
where material_id = 24;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=161"
where material_id = 25;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=167"
where material_id = 26;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=236"
where material_id = 27;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=32"
where material_id = 28;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=53"
where material_id = 29;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=169"
where material_id = 30;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=40"
where material_id = 31;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=40"
where material_id = 32;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=186"
where material_id = 33;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=169"
where material_id = 34;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=186"
where material_id = 35;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=163"
where material_id = 36;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=61"
where material_id = 37;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=63"
where material_id = 38;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=3"
where material_id = 39;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_8830919%2F88309197010.jpg&type=f372_372"
where material_id = 40;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=176"
where material_id = 41;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=47"
where material_id = 42;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=41"
where material_id = 43;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=172"
where material_id = 44;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=148"
where material_id = 45;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=57"
where material_id = 46;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=218"
where material_id = 47;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=159"
where material_id = 48;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=159"
where material_id = 49;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=156"
where material_id = 50;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_1098873%2F10988738513.10.jpg&type=f372_372"
where material_id = 51;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=76"
where material_id = 52;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=162"
where material_id = 53;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=162"
where material_id = 54;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=183"
where material_id = 55;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=178"
where material_id = 56;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_4136266%2F41362669401.jpg&type=f372_372"
where material_id = 57;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_2000166%2F20001663142.2.jpg&type=f372_372"
where material_id = 58;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=210"
where material_id = 59;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=43"
where material_id = 60;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=240"
where material_id = 61;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=157"
where material_id = 62;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fimgnews.naver.net%2Fimage%2F001%2F2021%2F07%2F28%2FC0A8CA3D000001644A964C4A0003A92D_P4_20210728162821793.jpeg&type=l340_165"
where material_id = 63;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=75"
where material_id = 64;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=75"
where material_id = 65;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=226"
where material_id = 66;

update yorijori.materials
set material_img = "https://search.pstatic.net/sunny/?src=https%3A%2F%2Fpng.pngtree.com%2Fpng-vector%2F20210526%2Fourlarge%2Fpngtree-banana-color-diet-health-png-image_3356828.png&type=a340"
where material_id = 67;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyNDA4MzFfMjgw%2FMDAxNzI1MDc1MDExOTI5.lWqmcf20qiblENxMLYUnG4a1IkAWL-CHBvJ3Yc3aNjIg.s65ea1neUDCNBD3s53PgqEPwWsfPd1dUO8jGwXgIkpkg.JPEG%2F2024-08-31_10_26_27.jpg&type=a340"
where material_id = 68;

update yorijori.materials
set material_img = "https://search.pstatic.net/sunny/?src=https%3A%2F%2Fpng.pngtree.com%2Fthumb_back%2Ffh260%2Fbackground%2F20230806%2Fpngtree-fresh-oranges-ready-to-slice-image_12975097.jpg&type=a340"
where material_id = 69;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=225"
where material_id = 70;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=235"
where material_id = 71;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=1"
where material_id = 72;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyNDA3MTJfMTcw%2FMDAxNzIwNzQzMDU2OTQ5.bu1I4WtcxQwREDc8sOheVCWgAd2s5zepp4qiOcuER5Eg.JqYKnqKxyQnJLKQeulBUEY_2YBUsBRkY5aP6iG_Oczwg.PNG%2Fimage.png&type=a340"
where material_id = 73;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fshop1.phinf.naver.net%2F20210608_233%2F1623117809942TocP5_JPEG%2F24253652648050855_274335721.jpg&type=a340"
where material_id = 74;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2F20100801_162%2Fwpdlfdirvna_1280595277329kQEh0_jpg%2Fsodengsim_1_wpdlfdirvna.jpg&type=a340"
where material_id = 75;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshop-phinf.pstatic.net%2F20220624_280%2F1656054484383IPbHL_JPEG%2F57190319205233010_250958975.jpg&type=a340"
where material_id = 76;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fshop1.phinf.naver.net%2F20230916_65%2F1694839775404CBvnp_JPEG%2F729467194739216_1230226355.jpg&type=a340"
where material_id = 77;

update yorijori.materials
set material_img = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLajazpxmrxCcnDDSPGCJk-f0q9BzK0W2gIg&s"
where material_id = 78;

update yorijori.materials
set material_img = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTU5OPhgDlD9UFBiJSpL-pE71JqTBFO90f3nw&s"
where material_id = 79;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fimage.nmv.naver.net%2Fblogucc28%2F2016%2F04%2F05%2F1830%2F426277c5cfb72a13ef60e88aa748f13caa97_ugcvideo_270P_01_16x9_logo.jpg&type=a340"
where material_id = 80;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyNDAyMTFfMTY4%2FMDAxNzA3NjUxOTE5NDg3.8vcA8LnJ11zKY-XZIYU79tMDziFf1Mh42Mt2K_Vc0MQg.yLjc2EelsyfKbGfSLS6V2aExuiVYXNvKGsuX6XvyQ8Mg.JPEG.yurife%2FIMG_8053.jpg&type=a340"
where material_id = 81;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fshop1.phinf.naver.net%2F20210613_3%2F1623574618341iQj9b_JPEG%2F24710452972239204_1808547517.jpg&type=a340"
where material_id = 82;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAxNzExMDFfNjAg%2FMDAxNTA5NTAyNTc2MjUx.0fPjtEah7KlJ8qbiR6fnyjFoKZGfQsKE15dSqzBr_O4g.MC_qX6xMNcuxKTpGr4F2LPgVCjgWlLnfJzoMidWxSCog.JPEG.suengcho%2F5.jpg&type=a340"
where material_id = 83;

update yorijori.materials
set material_img = "https://shopping-phinf.pstatic.net/main_8409062/84090628391.1.jpg?type=f300"
where material_id = 84;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_3423940%2F34239409419.jpg&type=f372_372"
where material_id = 85;

update yorijori.materials
set material_img = "https://www.kamis.or.kr/customer/archive/archive.do?action=image2&archiveNo=239"
where material_id = 86;

update yorijori.materials
set material_img = "https://searchad-phinf.pstatic.net/MjAyNDA1MTdfNiAg/MDAxNzE1ODk1NzI4Njgz.5-C67JyUMm9QfOgVvBEhiSVbnuX3pcJrz-kQtKWqCyMg.QbIGC6ant2Av9ZyaQ81nfdZN3H1AKphblCJ9sE5q32gg.JPEG/2765595-49819e03-c9fe-4602-98f9-d760a180529b.jpg?type=f160_160"
where material_id = 87;

update yorijori.materials
set material_img = "https://shopping-phinf.pstatic.net/main_8516871/85168710542.1.jpg?type=f300"
where material_id = 88;

update yorijori.materials
set material_img = "https://shopping-phinf.pstatic.net/main_8208266/82082664177.2.jpg?type=f300"
where material_id = 89;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_4552132%2F45521324358.jpg&type=f372_372"
where material_id = 90;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_8668876%2F86688765748.jpg&type=f372_372"
where material_id = 91;

update yorijori.materials
set material_img = "https://shopping-phinf.pstatic.net/main_9822585/9822585155.13.jpg?type=f300"
where material_id = 92;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_8572882%2F85728825923.5.jpg&type=f372_372"
where material_id = 93;

update yorijori.materials
set material_img = "https://shopping-phinf.pstatic.net/main_8712567/87125672808.3.jpg?type=f300"
where material_id = 94;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_8506476%2F85064764794.jpg&type=f372_372"
where material_id = 95;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fshop1.phinf.naver.net%2F20240216_185%2F1708048571537IXRAO_PNG%2F109184351162750851_436134233.png&type=a340"
where material_id = 96;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fshop1.phinf.naver.net%2F20240714_115%2F1720946607135BvoG8_JPEG%2F51733886947452536_97518524.jpg&type=a340"
where material_id = 97;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=https%3A%2F%2Fshopping-phinf.pstatic.net%2Fmain_8713469%2F87134693040.jpg&type=f372_372"
where material_id = 98;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyNDA4MjZfNTMg%2FMDAxNzI0NjM2NjY2Mjc5.Pcc6gh9alVhAjlQFn8AseCqkEhff7XG2PD3LKu7zbZQg.tmGwUnIadUr-uE-jeobA5hEdh45kgQNUe2OJ7QE8TZQg.PNG%2Fkjhgfdfghjg.png&type=a340"
where material_id = 99;

update yorijori.materials
set material_img = "https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyNDAzMjNfMzkg%2FMDAxNzExMTYwODIxMTQ1.a3wDK-qNdHYLefO38FsoXz5vHuZ5P8RjV_oIhPQOt8Ig.UiNBV6IVOG3IrP8J_cFbeMQxIB1mVN-w7E2-NI-G_Xgg.JPEG%2Fshrimp-1811954_1280.jpg&type=l340_165"
where material_id = 100;

update yorijori.materials
set material_img = "https://shopping-phinf.pstatic.net/main_8285246/82852465932.5.jpg?type=f300"
where material_id = 101;
